<template>
  <div id="not-found">
    <h1>Uh oh, something went wrong!</h1>
  </div>
</template>

<script>
export default {};
</script>

<style>
#not-found {
  background-image: url("../Assets/background.png");
  background-size: cover;
  position: absolute;
  top: 95px;
  right: 0px;
  bottom: 0px;
  left: 0px;
}
</style>